//after doing api call to server
//var data=$.getJSON(url,data,success(data,status,xhr))
var data = [
  {
    name: "rajiv",
    marks: {
      Maths: 18,
      English: 21,
      Science: 45,
    },
    rollNumber: "KV2017-5A2",
  },
  {
    name: "abhishek",
    marks: {
      Maths: 43,
      English: 30,
      Science: 37,
    },
    rollNumber: "KV2017-5A1",
  },
  {
    name: "zoya",
    marks: {
      Maths: 42,
      English: 31,
      Science: 50,
    },
    rollNumber: "KV2017-5A3",
  },
];

$(function () {
  for (var i = 0; i < data.length; i++) {
    console.log(data[i]);
    setDataIntoTr(data[i]);
  }
  setStatus();
  validateForm();
});

function setDataIntoTr(value) {
  var totMarks = 0;
  var marksData = Object.values(value["marks"]);
  var status = Math.min.apply(Math, marksData) < 20 ? "Fail" : "Pass";

  for (var i = 0; i < marksData.length; i++) {
    totMarks += marksData[i];
  }

  var trTag =
    "<tr><td>" +
    value["name"].substr(0, 1).toUpperCase() +
    value["name"].substr(1) +
    "</td><td>" +
    value["rollNumber"] +
    "</td><td>" +
    totMarks +
    "</td><td>" +
    status +
    "</td>  </tr>";

  $("table").append(trTag);
}
function setStatus() {
  var arrayOfMarks = [];
  $("table tr:not(:first-child)").each(function () {
    arrayOfMarks.push(parseInt($(this).find("td").eq(2).html()));
  });
  var min = Math.min.apply(Math, arrayOfMarks);
  var max = Math.max.apply(Math, arrayOfMarks);
  console.log(min, max);
  $("table tr:not(:first-child)").each(function () {
    var listOfTotMarks = $(this).find("td").eq(2).html();
    parseInt(listOfTotMarks) == min
      ? $(this).find("td").eq(2).parent("tr").addClass("addRedColor")
      : null;
    parseInt(listOfTotMarks) == max
      ? $(this).find("td").eq(2).parent("tr").addClass("addGreenColor")
      : null;
  });
  $("table tr:not(:first-child)").each(function () {
    $(this).hasClass("addGreenColor")
      ? $(this).find("td:last-child").text("Topper")
      : null;
  });
}

function validateForm()
{
  $("form").submit(function (e) {
    e.preventDefault();
    var firstName = $("#name").val();
    var lastName = $("#lastName").val();
    var Class = $("#class").val();
    var year = $("#year").val();

    $(".error").remove();

    if (firstName!="" && firstName.length < 21 && /^[a-z A-Z]+$/.test(firstName)) {
      
    } else {
      $('#name').after('<span class="error">First Name in invalid</span>');
    }
    if (lastName!="" && lastName.length < 21 && /^[a-z A-Z]+$/.test(lastName)) {
     
    } else {
        $('#lastName').after('<span class="error">Last Name is invalid</span>');
    }

    if (Class.length > 3) {
        $('#class').after('<span class="error">length exceeded the limit</span>');
    } 

    if (year > 2017) {
        $('#year').after('<span class="error">year should be less tahn 2017</span>');
    } 
    
  });
}
